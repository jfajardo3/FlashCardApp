package com.example.wishlist

class Wish
    (val productString: String,
                val priceString: String,
                val urlString: String)
{
}